package com.example.myapplication;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void aibutton(View view) {


        Intent intent = new Intent(MainActivity.this, AIActivity.class);
        startActivity(intent);
    }
    public void onClick2(View view) {
     Intent intent2 = new Intent(MainActivity.this, Activity.class);
        startActivity(intent2);
    }
protected void onStop() {
    super.onStop();
    final MediaPlayer mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.qwer);

    mediaPlayer.stop();

}
} 