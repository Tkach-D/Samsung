package com.example.myapplication;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.util.LinkedList;
import java.util.Scanner;
public class AIActivity extends AppCompatActivity {
        String CurrentCity;

    int points;
        String[] cities;
        String outMessage;
        LinkedList<String> used = new LinkedList<>();
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            String prevMessage = getString(R.string.currentcity);
            final MediaPlayer mediaPlayer = MediaPlayer.create(AIActivity.this, R.raw.qwer);
            mediaPlayer.start();
            outMessage="москва";
            CurrentCity = "москва";
            used.add("asd");
            used.add("sdf");
            cities = getResources().getStringArray(R.array.cities);
            points = 0;
            setContentView(R.layout.activity_ai);
            final MediaPlayer mediaPlayoer = MediaPlayer.create(AIActivity.this, R.raw.qwer);
            mediaPlayoer.start();
        }
        public void nextturn(View view){
            // try {

            TextView tv=(TextView)findViewById(R.id.outMessage);
            tv.setText(outMessage);
            TextView tv2=(TextView)findViewById(R.id.points);
            String pointsstring = String.valueOf(points);
            tv2.setText(pointsstring);
            char currentLetter = CurrentCity.charAt(CurrentCity.length()-1);
            char currentLetter2=CAPS_CYR(currentLetter);

            EditText editText = (EditText) findViewById(R.id.incity);
            String incity = editText.getText().toString();
            Boolean hasusedq = false;
            for(int i = 0 ; i <= used.size()-1;i++){
                if(used.contains(incity)){hasusedq=true;}
            }
            used.add(incity);
            if((incity.charAt(0)==currentLetter||incity.charAt(0)==currentLetter2) && (hasusedq==false|| used.contains(incity)==true)){

                char currentLetter3 = incity.charAt(incity.length()-1);
                char currentLetter4=CAPS_CYR(currentLetter3);
                int q= cities.length-1;

                for(int i = 0 ; i <= q;i++){
                    if((cities[i].charAt(0)==currentLetter3||cities[i].charAt(0)==currentLetter4) &&  used.contains(cities[i])==false){
                        CurrentCity = cities[i];
                        used.add(cities[i]);
                        break;
                    }
                }
                outMessage = CurrentCity;


                pointsstring = String.valueOf(points);
                points++;
                tv.setText(outMessage);
                tv2.setText(pointsstring);

                q--;
            }
            else{outMessage = "Не подходит";
                tv.setText(outMessage);
            }
            //  }
            //  catch (Exception ex)
            //  {
            //       Log.w("Exception error: ", ex.getMessage());
            //      Log.v("in line", ex.)
            //  }


        }
        public void onout(){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        protected void onStop(){
            final MediaPlayer mediaPlayer = MediaPlayer.create(AIActivity.this, R.raw.qwer);

            mediaPlayer.stop();
            super.onStop();

        };
        char CAPS_CYR(char currentLetter){
            char currentLetter2 = 'q';
            if(currentLetter=='q'){return currentLetter2='Q';}
            if(currentLetter=='w'){return currentLetter2='W';}
            if(currentLetter=='а'){return currentLetter2='А';}
            if(currentLetter=='б'){return currentLetter2='Б';}
            if(currentLetter=='в'){return currentLetter2='В';}
            if(currentLetter=='г'){return currentLetter2='Г';}
            if(currentLetter=='д'){return currentLetter2='Д';}
            if(currentLetter=='е'){return currentLetter2='Е';}
            if(currentLetter=='ё'){return currentLetter2='Ё';}
            if(currentLetter=='ж'){return currentLetter2='Ж';}
            if(currentLetter=='з'){return currentLetter2='З';}
            if(currentLetter=='и'){return currentLetter2='И';}
            if(currentLetter=='й'){return currentLetter2='Й';}
            if(currentLetter=='к'){return currentLetter2='К';}
            if(currentLetter=='л'){return currentLetter2='Л';}
            if(currentLetter=='м'){return currentLetter2='М';}
            if(currentLetter=='н'){return currentLetter2='Н';}
            if(currentLetter=='о'){return currentLetter2='О';}
            if(currentLetter=='п'){return currentLetter2='П';}
            if(currentLetter=='р'){return currentLetter2='Р';}
            if(currentLetter=='с'){return currentLetter2='С';}
            if(currentLetter=='т'){return currentLetter2='Т';}
            if(currentLetter=='у'){return currentLetter2='У';}
            if(currentLetter=='ф'){return currentLetter2='Ф';}
            if(currentLetter=='х'){return currentLetter2='Х';}
            if(currentLetter=='ц'){return currentLetter2='Ц';}
            if(currentLetter=='ч'){return currentLetter2='Ч';}
            if(currentLetter=='ш'){return currentLetter2='Ш';}
            if(currentLetter=='щ'){return currentLetter2='Щ';}
            if(currentLetter=='ь'){return currentLetter2='Ь';}
            if(currentLetter=='ы'){return currentLetter2='Ы';}
            if(currentLetter=='ъ'){return currentLetter2='Ъ';}
            if(currentLetter=='э'){return currentLetter2='Э';}
            if(currentLetter=='ю'){return currentLetter2='Ю';}
            if(currentLetter=='я'){return currentLetter2='Я';}
            if(currentLetter=='Q'){return currentLetter2='Q';}
            if(currentLetter=='W'){return currentLetter2='W';}
            if(currentLetter=='А'){return currentLetter2='а';}
            if(currentLetter=='Б'){return currentLetter2='б';}
            if(currentLetter=='В'){return currentLetter2='в';}
            if(currentLetter=='Г'){return currentLetter2='г';}
            if(currentLetter=='Д'){return currentLetter2='д';}
            if(currentLetter=='Е'){return currentLetter2='е';}
            if(currentLetter=='Ё'){return currentLetter2='ё';}
            if(currentLetter=='Ж'){return currentLetter2='ж';}
            if(currentLetter=='З'){return currentLetter2='з';}
            if(currentLetter=='И'){return currentLetter2='и';}
            if(currentLetter=='Й'){return currentLetter2='й';}
            if(currentLetter=='К'){return currentLetter2='к';}
            if(currentLetter=='Л'){return currentLetter2='л';}
            if(currentLetter=='М'){return currentLetter2='м';}
            if(currentLetter=='Н'){return currentLetter2='н';}
            if(currentLetter=='О'){return currentLetter2='о';}
            if(currentLetter=='П'){return currentLetter2='п';}
            if(currentLetter=='Р'){return currentLetter2='р';}
            if(currentLetter=='С'){return currentLetter2='с';}
            if(currentLetter=='Т'){return currentLetter2='т';}
            if(currentLetter=='У'){return currentLetter2='у';}
            if(currentLetter=='Ф'){return currentLetter2='ф';}
            if(currentLetter=='Х'){return currentLetter2='х';}
            if(currentLetter=='Ц'){return currentLetter2='ц';}
            if(currentLetter=='Ч'){return currentLetter2='ч';}
            if(currentLetter=='Ш'){return currentLetter2='ш';}
            if(currentLetter=='Щ'){return currentLetter2='щ';}
            if(currentLetter=='Ь'){return currentLetter2='ь';}
            if(currentLetter=='Ы'){return currentLetter2='ы';}
            if(currentLetter=='Ъ'){return currentLetter2='ъ';}
            if(currentLetter=='Э'){return currentLetter2='э';}
            if(currentLetter=='Ю'){return currentLetter2='ю';}
            if(currentLetter=='Я'){return currentLetter2='я';}
            return currentLetter2;
        }


    }
