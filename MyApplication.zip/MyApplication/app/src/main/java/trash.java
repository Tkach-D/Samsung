public class trash {
          /*  InputStream ins = getResources().openRawResource(R.raw.usedcities);
            Scanner s = new Scanner(ins).useDelimiter("\\A");
            String usedcitiesMS = s.hasNext() ? s.next() : "";
            InputStream ins2 = getResources().openRawResource(R.raw.cities);
            Scanner s1 = new Scanner(ins).useDelimiter("\\A");
            String citiesMS = s.hasNext() ? s.next() : "";
            InputStream ins3 = getResources().openRawResource(R.raw.unedited);
            Scanner s2 = new Scanner(ins).useDelimiter("\\A");
            String uneditedMS = s.hasNext() ? s.next() : "";
            BufferedReader br = new BufferedReader(new FileReader(usedcitiesMS));

            while ((br.readLine()) != null) {
                line1.add(br.readLine());
            }
            StringBuilder text = new StringBuilder();
            String line;
                FileInputStream fileInputStream = new FileInputStream (citiesMS);
                InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                StringBuilder stringBuilder = new StringBuilder();

                while ( (line = bufferedReader.readLine()) != null )
                {
                    stringBuilder.append(line + System.getProperty("line.separator"));
                }
                fileInputStream.close();
                line = stringBuilder.toString();

                bufferedReader.close();
            CharSequence incitysequence = (CharSequence) incity;
            if(line.contains(incitysequence) == false) {
                String outtext = ("Нет такого города!");
            }
            boolean v = false;
            List<String> Nline = new LinkedList<String>();
            Object[] mass0 =line0.toArray();
            for(int i = 0 ; i < line0.size();i++){
                String str = mass0[i].toString();
                if(str == incity){
                    v = true;
                    break;
                }
            }
            if(v == true) {
                String outtext = ("Город уже использован!");
            }
            else{
                try {
                    // отрываем поток для записи
                    //getResources().getStringArray( R.raw.);



             ////       InputStream ins2 = getResources().openRawResource(
                 //           getResources().getIdentifier("usedcities",
              ////                      "raw", getPackageName()));

                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(openFileOutput(usedcitiesMS, MODE_PRIVATE)));
                    // пишем данные
                    bw.write(incity);
                    // закрываем поток
                    bw.close();
                    // Log.d(LOG_TAG, "Файл записан");
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }//записали входной
                int q = incity.length();
                char fl = incity.charAt(q);
String outcity;
                List<String> Lline = new LinkedList<String>();

               Object[] mass = line0.toArray();
for(int i = 0 ; i < line0.size();i++){
    String str = mass[i].toString();
if(str.charAt(str.charAt(0)) == fl){
    Lline.add(str);
}
}
                Object[] mass1 = Lline.toArray();
                int random_number1 = 0 + (int) (Math.random() * Lline.size());
outcity = (String) mass1[random_number1];
                CharSequence outsequence = (CharSequence) outcity;
                if(line1.contains(outsequence) == false) {
                    String outtext = outcity;
                    currentCity = outtext;
                }
                else{

                }
            }
*/

/*    FileOutputStream writer = null;
    InputStream ins = getResources().openRawResource(R.raw.usedcities);
    Scanner s = new Scanner(ins).useDelimiter("\\A");
    String usedcitiesMS = s.hasNext() ? s.next() : "";
    InputStream ins2 = getResources().openRawResource(R.raw.cities);
    Scanner s1 = new Scanner(ins).useDelimiter("\\A");
    String citiesMS = s.hasNext() ? s.next() : "";
    InputStream ins3 = getResources().openRawResource(R.raw.unedited);
    Scanner s2 = new Scanner(ins).useDelimiter("\\A");
    String uneditedMS = s.hasNext() ? s.next() : "";
        try {
        writer = new FileOutputStream(citiesMS);
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }
        try {
        writer.write(("").getBytes());
    } catch (IOException e) {
        e.printStackTrace();
    }
        try {
        writer.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
        try {
        // отрываем поток для записи
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
                openFileOutput(citiesMS, MODE_PRIVATE)));
        // пишем данные

        bw.write(uneditedMS);
        // закрываем поток
        bw.close();
        // Log.d(LOG_TAG, "Файл записан");
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }//записали входной*/
}
