package com.example.myapplication;
import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class AIGameActivity extends AppCompatActivity {
  //  String instanceName = "DESKTOP-0P5VR0E\\SQLEXPRESS";
 //   String db = "Cities";
  //  String username = "Dan";
   // String password = "gigant65";
   // String connectionUrl = "jdbc:sqlserver://%1$s;databaseName=%2$s;user=%3$s;password=%4$s;";
  //  String connectionString = String.format(connectionUrl, instanceName, db, username, password);
    String CurrentCity = "москва";
int points;


    String[] cities = getResources().getStringArray(R.array.cities);




    String[] cities2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cities2=cities;
        setContentView(R.layout.activity_aigame);
points=0;        try {
           /* Scanner scan = new Scanner(System.in);
            InputStream ins = getResources().openRawResource(R.values.strings);
            Scanner s = new Scanner(ins).useDelimiter("\\A");
            String usedcitiesMS = s.hasNext() ? s.next() : "";
            InputStream ins2 = getResources().openRawResource(R.raw.cities);
            Scanner s1 = new Scanner(ins).useDelimiter("\\A");
            String citiesMS = s.hasNext() ? s.next() : "";
            InputStream ins3 = getResources().openRawResource(R.raw.unedited);
            Scanner s2 = new Scanner(ins).useDelimiter("\\A");
            String uneditedMS = s.hasNext() ? s.next() : "";

            BufferedReader br = new BufferedReader(new FileReader(citiesMS));

            while ((br.readLine()) != null) {
                line0.add(br.readLine());
            }
        }*/

        }
        catch(Exception e){e.printStackTrace();}
    }
    public void nextturn(View view) {
        try {
            Scanner scan = new Scanner(System.in);
            char currentLetter = CurrentCity.charAt(CurrentCity.length());
            char currentLetter2=CAPS_CYR(currentLetter);
            String outText;
            String outMessage;
            EditText editText = (EditText) findViewById(R.id.incity);
            String incity = editText.getText().toString();
            if(incity.charAt(0)==currentLetter||incity.charAt(0)==currentLetter2){
                char currentLetter3 = incity.charAt(incity.length());
                char currentLetter4=CAPS_CYR(currentLetter3);
                int q=
                cities.length;


                for(int i = 0 ; i <= q;i++){
                    if(cities2[i].charAt(0)==currentLetter3||cities2[i].charAt(0)==currentLetter4){
                        CurrentCity = cities2[i];
                        cities2[i] = "";
                        break;
                    }
                }
                outMessage = CurrentCity;
            }
            else{outMessage = "Нет такого города";}
          /*  InputStream ins = getResources().openRawResource(R.raw.usedcities);
            Scanner s = new Scanner(ins).useDelimiter("\\A");
            String usedcitiesMS = s.hasNext() ? s.next() : "";
            InputStream ins2 = getResources().openRawResource(R.raw.cities);
            Scanner s1 = new Scanner(ins).useDelimiter("\\A");
            String citiesMS = s.hasNext() ? s.next() : "";
            InputStream ins3 = getResources().openRawResource(R.raw.unedited);
            Scanner s2 = new Scanner(ins).useDelimiter("\\A");
            String uneditedMS = s.hasNext() ? s.next() : "";
            BufferedReader br = new BufferedReader(new FileReader(usedcitiesMS));

            while ((br.readLine()) != null) {
                line1.add(br.readLine());
            }
            StringBuilder text = new StringBuilder();
            String line;
                FileInputStream fileInputStream = new FileInputStream (citiesMS);
                InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                StringBuilder stringBuilder = new StringBuilder();

                while ( (line = bufferedReader.readLine()) != null )
                {
                    stringBuilder.append(line + System.getProperty("line.separator"));
                }
                fileInputStream.close();
                line = stringBuilder.toString();

                bufferedReader.close();
            CharSequence incitysequence = (CharSequence) incity;
            if(line.contains(incitysequence) == false) {
                String outtext = ("Нет такого города!");
            }
            boolean v = false;
            List<String> Nline = new LinkedList<String>();
            Object[] mass0 =line0.toArray();
            for(int i = 0 ; i < line0.size();i++){
                String str = mass0[i].toString();
                if(str == incity){
                    v = true;
                    break;
                }
            }
            if(v == true) {
                String outtext = ("Город уже использован!");
            }
            else{
                try {
                    // отрываем поток для записи
                    //getResources().getStringArray( R.raw.);



             ////       InputStream ins2 = getResources().openRawResource(
                 //           getResources().getIdentifier("usedcities",
              ////                      "raw", getPackageName()));

                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(openFileOutput(usedcitiesMS, MODE_PRIVATE)));
                    // пишем данные
                    bw.write(incity);
                    // закрываем поток
                    bw.close();
                    // Log.d(LOG_TAG, "Файл записан");
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }//записали входной
                int q = incity.length();
                char fl = incity.charAt(q);
String outcity;
                List<String> Lline = new LinkedList<String>();

               Object[] mass = line0.toArray();
for(int i = 0 ; i < line0.size();i++){
    String str = mass[i].toString();
if(str.charAt(str.charAt(0)) == fl){
    Lline.add(str);
}
}
                Object[] mass1 = Lline.toArray();
                int random_number1 = 0 + (int) (Math.random() * Lline.size());
outcity = (String) mass1[random_number1];
                CharSequence outsequence = (CharSequence) outcity;
                if(line1.contains(outsequence) == false) {
                    String outtext = outcity;
                    currentCity = outtext;
                }
                else{

                }
            }
*/          }
        catch (Exception ex)
        {
            Log.w("Exception error: ", ex.getMessage());
        }


    }

    protected void onStop(){

        super.onStop();
        FileOutputStream writer = null;
        InputStream ins = getResources().openRawResource(R.raw.usedcities);
        Scanner s = new Scanner(ins).useDelimiter("\\A");
        String usedcitiesMS = s.hasNext() ? s.next() : "";
        InputStream ins2 = getResources().openRawResource(R.raw.cities);
        Scanner s1 = new Scanner(ins).useDelimiter("\\A");
        String citiesMS = s.hasNext() ? s.next() : "";
        InputStream ins3 = getResources().openRawResource(R.raw.unedited);
        Scanner s2 = new Scanner(ins).useDelimiter("\\A");
        String uneditedMS = s.hasNext() ? s.next() : "";
        try {
            writer = new FileOutputStream(citiesMS);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            writer.write(("").getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            // отрываем поток для записи
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
                    openFileOutput(citiesMS, MODE_PRIVATE)));
            // пишем данные

            bw.write(uneditedMS);
            // закрываем поток
            bw.close();
            // Log.d(LOG_TAG, "Файл записан");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }//записали входной
    };
char CAPS_CYR(char currentLetter){
    char currentLetter2 = 'q';
        if(currentLetter=='q'){return currentLetter2='Q';}
        if(currentLetter=='w'){return currentLetter2='W';}
        if(currentLetter=='а'){return currentLetter2='А';}
        if(currentLetter=='б'){return currentLetter2='Б';}
        if(currentLetter=='в'){return currentLetter2='В';}
        if(currentLetter=='г'){return currentLetter2='Г';}
        if(currentLetter=='д'){return currentLetter2='Д';}
        if(currentLetter=='е'){return currentLetter2='Е';}
        if(currentLetter=='ё'){return currentLetter2='Ё';}
        if(currentLetter=='ж'){return currentLetter2='Ж';}
        if(currentLetter=='з'){return currentLetter2='З';}
        if(currentLetter=='и'){return currentLetter2='И';}
        if(currentLetter=='й'){return currentLetter2='Й';}
        if(currentLetter=='к'){return currentLetter2='К';}
        if(currentLetter=='л'){return currentLetter2='Л';}
        if(currentLetter=='м'){return currentLetter2='М';}
        if(currentLetter=='н'){return currentLetter2='Н';}
        if(currentLetter=='о'){return currentLetter2='О';}
        if(currentLetter=='п'){return currentLetter2='П';}
        if(currentLetter=='р'){return currentLetter2='Р';}
        if(currentLetter=='с'){return currentLetter2='С';}
        if(currentLetter=='т'){return currentLetter2='Т';}
        if(currentLetter=='у'){return currentLetter2='У';}
        if(currentLetter=='ф'){return currentLetter2='Ф';}
        if(currentLetter=='х'){return currentLetter2='Х';}
        if(currentLetter=='ц'){return currentLetter2='Ц';}
        if(currentLetter=='ч'){return currentLetter2='Ч';}
        if(currentLetter=='ш'){return currentLetter2='Ш';}
        if(currentLetter=='щ'){return currentLetter2='Щ';}
        if(currentLetter=='ь'){return currentLetter2='Ь';}
        if(currentLetter=='ы'){return currentLetter2='Ы';}
        if(currentLetter=='ъ'){return currentLetter2='Ъ';}
        if(currentLetter=='э'){return currentLetter2='Э';}
        if(currentLetter=='ю'){return currentLetter2='Ю';}
        if(currentLetter=='я'){return currentLetter2='Я';}
        return currentLetter2;
}}
