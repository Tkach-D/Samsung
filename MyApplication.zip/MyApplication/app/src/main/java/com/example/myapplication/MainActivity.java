package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    protected void onClickSettings(View view) {
        Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
      startActivity(intent);
    }
    public void aibutton(View view) {


        Intent intent = new Intent(MainActivity.this, AIActivity.class);
        startActivity(intent);
    }
  //  protected void onClick2(View view) {
  //      Intent intent = new Intent(MainActivity.this, Activity.class);
   //     startActivity(intent);
   // }

} 